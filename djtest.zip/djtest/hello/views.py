from django.shortcuts import render
from .forms import NumbersForm

# Create your views here.


def index(request):

    if request.method == "POST":
        form = NumbersForm(request.POST)
        if form.is_valid():
            context = {}
            context.update(form.cleaned_data)
            return render(request, 'hello/index.html', context)

    context = {"name": 'unknown guest', 'form': NumbersForm()}
    return render(request, 'hello/index.html', context)
